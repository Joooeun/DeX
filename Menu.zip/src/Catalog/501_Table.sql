SELECT 
  tabschema
, tabname   
, type
, status
, create_time
, value(stats_time,'0001-01-01-00.00.00.000000') stats_time
, colcount
, card
, npages
, fpages
, overflow
, tbspace
, keycolumns
, partition_mode
, pctfree
, locksize
FROM syscat.tables
WHERE tabschema like '%'|| UCASE(REPLACE(:tabschema,' ','')) ||'%'
  AND tabname   like UCASE(REPLACE(:tabname,' ','')) ||'%'
ORDER BY tabschema, tabname 
FOR FETCH ONLY
 WITH UR