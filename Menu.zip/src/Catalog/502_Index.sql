SELECT 
  indschema
, indname
, tabschema
, tabname
, uniquerule
, colcount
, unique_colcount
, indextype
, entrytype
, pctfree
, nleaf
, nlevels
, clusterratio
, clusterfactor
, density
, num_empty_leafs
, create_time
, VALUE(stats_time,'0001-01-01-00.00.00.000000') stats_time
, minpctused
--, reverse_scans 
FROM syscat.indexes
WHERE tabschema = UCASE( :tabschema )
  AND tabname   = UCASE( :tabname )
ORDER BY indschema, indname 
OPTIMIZE FOR 1 ROWS
FOR FETCH ONLY
WITH UR