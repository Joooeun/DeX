SELECT 
  tabschema 
, tabname 
, colname
, colno
, typename 
, length
, scale
, nulls
, colcard
, VALUE(high2key, ' ') high2key
, VALUE(low2key , ' ') low2key
, avgcollen
, numnulls
, identity
, generated
FROM syscat.columns
WHERE tabschema = UCASE( :tabschema )
  AND tabname   = UCASE( :tabname  )
ORDER BY colno 
FETCH FIRST 20 ROWS ONLY
OPTIMIZE FOR 1 ROWS
FOR FETCH ONLY
WITH UR