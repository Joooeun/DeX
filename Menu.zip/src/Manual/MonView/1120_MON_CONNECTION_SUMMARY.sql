SELECT 
  APPLICATION_HANDLE                     
, APPLICATION_NAME                       
, APPLICATION_ID                         
, SESSION_AUTH_ID                        
, TOTAL_APP_COMMITS                      
, TOTAL_APP_ROLLBACKS                    
, ACT_COMPLETED_TOTAL                    
, APP_RQSTS_COMPLETED_TOTAL              
, AVG_RQST_CPU_TIME                      
, ROUTINE_TIME_RQST_PERCENT              
, RQST_WAIT_TIME_PERCENT                 
, ACT_WAIT_TIME_PERCENT                  
, IO_WAIT_TIME_PERCENT                   
, LOCK_WAIT_TIME_PERCENT                 
, AGENT_WAIT_TIME_PERCENT                
, NETWORK_WAIT_TIME_PERCENT              
, SECTION_PROC_TIME_PERCENT              
, SECTION_SORT_PROC_TIME_PERCENT         
, COMPILE_PROC_TIME_PERCENT              
, TRANSACT_END_PROC_TIME_PERCENT         
, UTILS_PROC_TIME_PERCENT                
, AVG_LOCK_WAITS_PER_ACT                 
, AVG_LOCK_TIMEOUTS_PER_ACT              
, AVG_DEADLOCKS_PER_ACT                  
, AVG_LOCK_ESCALS_PER_ACT                
, ROWS_READ_PER_ROWS_RETURNED            
, TOTAL_BP_HIT_RATIO_PERCENT             
, TOTAL_GBP_HIT_RATIO_PERCENT            
, TOTAL_CACHING_TIER_HIT_RATIO_PERCENT   
, CF_WAIT_TIME_PERCENT                   
, RECLAIM_WAIT_TIME_PERCENT              
, SPACEMAPPAGE_RECLAIM_WAIT_TIME_PERCENT                  
FROM sysibmadm.MON_CONNECTION_SUMMARY 
WHERE  1=1
  AND  APPLICATION_HANDLE <> MON_GET_APPLICATION_HANDLE() 
ORDER BY AVG_RQST_CPU_TIME
FOR FETCH ONLY
 WITH UR