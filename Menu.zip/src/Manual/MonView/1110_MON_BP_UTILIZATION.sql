SELECT 
  BP_NAME                                                                          
, MEMBER                                                                           
, DATA_PHYSICAL_READS                                                              
, DATA_HIT_RATIO_PERCENT                                                           
, INDEX_PHYSICAL_READS                                                             
, INDEX_HIT_RATIO_PERCENT                                                          
, XDA_PHYSICAL_READS                                                               
, XDA_HIT_RATIO_PERCENT                                                            
, COL_PHYSICAL_READS                                                               
, COL_HIT_RATIO_PERCENT                                                            
, TOTAL_PHYSICAL_READS                                                             
, AVG_PHYSICAL_READ_TIME                                                           
, PREFETCH_RATIO_PERCENT                                                           
, ASYNC_NOT_READ_PERCENT                                                           
, TOTAL_WRITES                                                                     
, AVG_WRITE_TIME                                                                   
, SYNC_WRITES_PERCENT                                                              
, GBP_DATA_HIT_RATIO_PERCENT                                                       
, GBP_INDEX_HIT_RATIO_PERCENT                                                      
, GBP_XDA_HIT_RATIO_PERCENT                                                        
, GBP_COL_HIT_RATIO_PERCENT                                                        
, CACHING_TIER_DATA_HIT_RATIO_PERCENT                                              
, CACHING_TIER_INDEX_HIT_RATIO_PERCENT                                             
, CACHING_TIER_XDA_HIT_RATIO_PERCENT                                               
, CACHING_TIER_COL_HIT_RATIO_PERCENT                                               
, AVG_SYNC_READ_TIME                                                               
, AVG_ASYNC_READ_TIME                                                              
, AVG_SYNC_WRITE_TIME                                                              
, AVG_ASYNC_WRITE_TIME                   
FROM sysibmadm.MON_BP_UTILIZATION 
WHERE  1=1
  AND BP_NAME NOT LIKE 'IBMSYSTEMBP%K'
ORDER BY BP_NAME
FOR FETCH ONLY
 WITH UR